ModTools.makeBuilding("oak_log", (superClass) => { return {
    walkAround: function(citizen, stepsInBuilding) {
        if (random_Random.getInt(3) == 1) {
            citizen.changeFloor();
            return;
        }

        //Slowly move in the house
        citizen.moveAndWaitRandom(3, 17, 60, 90, null, false, true);
    },
    get_possibleUpgrades: function() {
        return [];
    }
};}, "spr_oak_log");

ModTools.makeBuilding("oak_planks", (superClass) => { return {
    walkAround: function(citizen, stepsInBuilding) {
        if (random_Random.getInt(3) == 1) {
            citizen.changeFloor();
            return;
        }

        //Slowly move in the house
        citizen.moveAndWaitRandom(3, 17, 60, 90, null, false, true);
    },
    get_possibleUpgrades: function() {
        return [];
    }
};}, "spr_oak_plank");

ModTools.makeBuilding("sand", (superClass) => { return {
    walkAround: function(citizen, stepsInBuilding) {
        if (random_Random.getInt(3) == 1) {
            citizen.changeFloor();
            return;
        }

        //Slowly move in the house
        citizen.moveAndWaitRandom(3, 17, 60, 90, null, false, true);
    },
    get_possibleUpgrades: function() {
        return [];
    }
};}, "spr_sand");

ModTools.makeBuilding("grass_block", (superClass) => { return {
    walkAround: function(citizen, stepsInBuilding) {
        if (random_Random.getInt(3) == 1) {
            citizen.changeFloor();
            return;
        }

        //Slowly move in the house
        citizen.moveAndWaitRandom(3, 17, 60, 90, null, false, true);
    },
    get_possibleUpgrades: function() {
        return [];
    }
};}, "spr_grass_block");

ModTools.makeBuilding("dirt", (superClass) => { return {
    walkAround: function(citizen, stepsInBuilding) {
        if (random_Random.getInt(3) == 1) {
            citizen.changeFloor();
            return;
        }

        //Slowly move in the house
        citizen.moveAndWaitRandom(3, 17, 60, 90, null, false, true);
    },
    get_possibleUpgrades: function() {
        return [];
    }
};}, "spr_dirt");

ModTools.makeBuilding("cobblestone", (superClass) => { return {
    walkAround: function(citizen, stepsInBuilding) {
        if (random_Random.getInt(3) == 1) {
            citizen.changeFloor();
            return;
        }

        //Slowly move in the house
        citizen.moveAndWaitRandom(3, 17, 60, 90, null, false, true);
    },
    get_possibleUpgrades: function() {
        return [];
    }
};}, "spr_cobblestone");

ModTools.makeBuilding("glass", (superClass) => { return {
    walkAround: function(citizen, stepsInBuilding) {
        if (random_Random.getInt(3) == 1) {
            citizen.changeFloor();
            return;
        }

        //Slowly move in the house
        citizen.moveAndWaitRandom(3, 17, 60, 90, null, false, true);
    },
    get_possibleUpgrades: function() {
        return [];
    }
};}, "spr_glass");

ModTools.makeBuilding("fullgrass", (superClass) => { return {
    walkAround: function(citizen, stepsInBuilding) {
        if (random_Random.getInt(3) == 1) {
            citizen.changeFloor();
            return;
        }

        //Slowly move in the house
        citizen.moveAndWaitRandom(3, 17, 60, 90, null, false, true);
    },
    get_possibleUpgrades: function() {
        return [];
    }
};}, "spr_fullgrass")

ModTools.makeBuilding("void", (superClass) => { return {
    walkAround: function(citizen, stepsInBuilding) {
        if (random_Random.getInt(3) == 1) {
            citizen.changeFloor();
            return;
        }

        //Slowly move in the house
        citizen.moveAndWaitRandom(3, 17, 60, 90, null, false, true);
    },
    get_possibleUpgrades: function() {
        return [];
    }
};}, "spr_air");

ModTools.makeBuilding("smoothstone", (superClass) => { return {
    walkAround: function(citizen, stepsInBuilding) {
        if (random_Random.getInt(3) == 1) {
            citizen.changeFloor();
            return;
        }

        //Slowly move in the house
        citizen.moveAndWaitRandom(3, 17, 60, 90, null, false, true);
    },
    get_possibleUpgrades: function() {
        return [];
    }
};}, "spr_smoothstone");

ModTools.makeBuilding("stonebrick", (superClass) => { return {
    walkAround: function(citizen, stepsInBuilding) {
        if (random_Random.getInt(3) == 1) {
            citizen.changeFloor();
            return;
        }

        //Slowly move in the house
        citizen.moveAndWaitRandom(3, 17, 60, 90, null, false, true);
    },
    get_possibleUpgrades: function() {
        return [];
    }
};}, "spr_stonebrick");